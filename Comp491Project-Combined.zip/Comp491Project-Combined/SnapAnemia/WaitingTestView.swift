//
//  WaitingTestView.swift
//  Deneme
//
//  Created by Pınar on 24.04.2024.
//

import SwiftUI

struct WaitingTestView: View{
    var input_img: CGImage?
    var patient_id: String
    @Binding var selectedTestFile: TestFile?
    @State private var test_file: TestFile?
    @State private var skel_im: UIImage?
    @State var test_finished = false
    @State private var dotIndex = 0
    @State private var navigationController = UINavigationController()
    @State var showAlert = false
    @State var showCameraView = false
    @State private var testFiles: [TestFile] = []
    @Binding var pmodel_isPhototaken: Bool
    @Binding var isCameraViewPresented: Bool
    @Environment(\.testListPresentation) var testListPresentation: Binding<Bool>
    let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    
    var body: some View {
        
        Color.white
            .ignoresSafeArea()
            .overlay(
                ZStack{
                    HStack {
                        Spacer()
                        Text("Analyzing")
                            .font(.title)
                            .padding()
                            .foregroundStyle(.black)
                        ForEach(0..<4) { index in
                            Text(".")
                                .font(.system(size: 40, weight: .bold, design: .rounded))
                                .opacity(dotIndex > index ? 1.0 : 0.0)
                                .animation(.easeInOut(duration: 0.5))
                                .foregroundStyle(.black)
                        }
                        Spacer()
                            .onReceive(timer) { _ in
                                withAnimation {
                                    dotIndex = (dotIndex + 1) % 4
                                }
                            }
                    }
                }
                    .navigationBarHidden(true)
                    .alert(isPresented: $showAlert) {
                        Alert(
                            title: Text("Warning"),
                            message: Text("Please make sure that the entire hand is visible"),
                            dismissButton: .default(Text("OK"), action: {
                                pmodel_isPhototaken = false
//                                showCameraView = true
                            })
                        )
                    }
            )
            .onAppear{
                DispatchQueue.global(qos: .background).async {
                    
                    let hlHandler = HandLandmarkHandler()
                    do{
                        var palm_im = try hlHandler.get_palm(image: self.input_img!)
                        var nail_im = try hlHandler.get_nails(image: self.input_img!)
                        self.skel_im = try hlHandler.drawOnImage(image: self.input_img!)
                        let date = TestFileManager.getCurrentDate()
                        test_file = TestFile(id: date, patientid: self.patient_id, anemia: false, date: date)
                        TestFileManager.addTestFile(testFile: test_file!, image: UIImage(cgImage: self.input_img!).rotate(radians: .pi/2)!){
                            error in
                            if let error=error{
                                print("Error Occured----------\n")
                                print(error.localizedDescription)
                            }
                            else{
                                TestFileManager.fetchTestFiles(forPatientWithID: patient_id) { files in
                                    DispatchQueue.main.async {
                                        testFiles = files
                                  
                                        print("----------------TestFiles------------")
                                        print(testFiles)
                                        self.selectedTestFile = testFiles.first(where: { $0.id == date })
                                        
                                        print("Writing selected file -----")
                                        print(self.selectedTestFile)
                                        isCameraViewPresented = false
                                    }
                                }
                            }
                        
                        }
                    }
                    catch{
                        self.showAlert = true
                        
                    }
                    
                }
            }
            
        
    }
}

//#Preview {
//    WaitingTestView(input_img_d: , patient_id: "123")
//}
