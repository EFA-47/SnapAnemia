import CoreGraphics
import SwiftUI

struct pickAreaView: View {
    let image: UIImage
    @Binding var rectToCrop: CGRect?
    @Binding var customSquarePressed: Bool
    @Binding var images: [UIImage]
    @State var coors: [CGPoint] = []
    @State var drawn_im: UIImage? = nil
    let scaled_w = UIScreen.main.bounds.width - 5
    let scaled_h = UIScreen.main.bounds.width*(1/0.75)
    var body: some View {
        Color.white
            .ignoresSafeArea()
            .overlay(
        VStack {
            Text("Please pick four points to form a square.")
                .frame(width:scaled_w-10, height:60)
                .background(Color.orange)
                .foregroundColor(.white)
                .cornerRadius(15)
                .padding()
            if drawn_im != nil{
                Image(uiImage: drawn_im!)
                    .resizable()
                    .frame(width: scaled_w, height: scaled_h)
                    .cornerRadius(20)
                    .onTapGesture (coordinateSpace: .local){location in
                        print("Tap loc: \(location.x)")
                        print(image.size.width)
                        print(UIScreen.main.bounds.height / 2 * 0.75)
                        let x = location.x/scaled_w * drawn_im!.size.width
                        let y = location.y/scaled_h * drawn_im!.size.height
                        if coors.count < 4{
                            coors.append(CGPoint(x: x, y: y))
                            drawn_im = DrawCircle(x: x, y: y, image: drawn_im!)!
                            if coors.count == 4 {
//                                coors.sort(by: {$0.x < $1.x})
                                let drawing_w = max(coors[0].x, coors[1].x, coors[2].x) - min(coors[0].x, coors[1].x, coors[2].x)
                                let drawing_h = max(coors[0].y, coors[1].y, coors[2].y) - min(coors[0].y, coors[1].y, coors[2].y)
                                let sorted_c = coors.sorted(by: {$0.x < $1.x})
                                
                                if sorted_c[0].y < sorted_c[1].y{
                                    drawn_im = DrawRect(x: sorted_c[0].x, y: sorted_c[0].y, w: drawing_w, h: drawing_h, image: drawn_im!)
                                    rectToCrop = CGRect(x: sorted_c[0].x, y: sorted_c[0].y, width: drawing_w, height: drawing_h)
                                }
                                else if sorted_c[1].y < sorted_c[0].y{
                                    drawn_im = DrawRect(x: sorted_c[1].x, y: sorted_c[1].y, w: drawing_w, h: drawing_h, image: drawn_im!)
                                    rectToCrop = CGRect(x: sorted_c[1].x, y: sorted_c[1].y, width: drawing_w, height: drawing_h)
                                }
                                
                                
                            }
                        }
                    }
            }
            
            HStack{
                Button(action: {
                    EraseCircle()
                }){
                    
                    Text("Undo")
                    
                        .frame(width:scaled_w/2.5, height: 60)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                }
                
                .padding(.init(top:30, leading:scaled_w/9, bottom:15, trailing: scaled_w/9))
                Button(action: {
                    
                    if coors.count == 0 || coors.count == 4{
                        if drawn_im != image{
                            images.append(DrawRect(x: rectToCrop!.minX, y: rectToCrop!.minY, w: rectToCrop!.width, h: rectToCrop!.height, image: image)!)
                        }
                        customSquarePressed = false
                    }
                }){
                    
                    Text("Done")
                        
                        .frame(width:scaled_w/2.5, height: 60)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                }
                .padding(.init(top:30, leading:0, bottom:15, trailing: scaled_w/9))
                
            }
        }
        .onAppear{
            drawn_im = image
        }
        )
    }
        
    
    func EraseCircle(){
        if self.coors.count > 0{
            self.coors.popLast()
            
            var temp_im = image
            for p in self.coors{
                temp_im = DrawCircle(x: p.x, y: p.y, image: temp_im)!
            }
            drawn_im = temp_im
        }
    }
}


func DrawCircle(x: CGFloat, y: CGFloat, image: UIImage) ->UIImage?{
    let renderer = UIGraphicsBeginImageContext(image.size)
    image.draw(at: CGPoint.zero)
    let context = UIGraphicsGetCurrentContext()!
    
    context.setStrokeColor(UIColor.green.cgColor)
    context.setAlpha(1)
    context.setLineWidth(25.0)
    context.addEllipse(in: CGRect(x: x, y: y, width: 40, height: 40))
    context.drawPath(using: .stroke)

    
    let myImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return myImage
}

func DrawRect(x: CGFloat, y: CGFloat, w: CGFloat, h:CGFloat, image: UIImage) ->UIImage?{
    let renderer = UIGraphicsBeginImageContext(image.size)
    image.draw(at: CGPoint.zero)
    let context = UIGraphicsGetCurrentContext()!
    
    context.setStrokeColor(UIColor.green.cgColor)
    context.setAlpha(1)
    context.setLineWidth(25.0)
    context.addRect(CGRect(x: x, y: y, width: w, height: h))
    context.drawPath(using: .stroke)

    
    let myImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return myImage
}

//#Preview {
//    ContentView()
//}

