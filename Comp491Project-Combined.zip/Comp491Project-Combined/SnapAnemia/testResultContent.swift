//
//  testResultContent.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 25.03.2024.
//

import SwiftUI
import SDWebImageSwiftUI
import UIKit

func processImage(_ image: UIImage) -> Double? {
    guard let cgImage = image.cgImage else { return nil }
    let width = cgImage.width
    let height = cgImage.height
    
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    let rawData = calloc(height * width * 4, MemoryLayout<UInt8>.size)
    let bytesPerPixel = 4
    let bytesPerRow = bytesPerPixel * width
    let bitsPerComponent = 8
    
    let context = CGContext(data: rawData,
                            width: width,
                            height: height,
                            bitsPerComponent: bitsPerComponent,
                            bytesPerRow: bytesPerRow,
                            space: colorSpace,
                            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    
    context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
    
    guard let data = rawData else { return nil }
    let pixelBuffer = data.bindMemory(to: UInt8.self, capacity: height * width * 4)
    
    var eimap = Array(repeating: Array(repeating: 0.0, count: width), count: height)
    
    for i in 0..<height {
        for j in 0..<width {
            let pixelIndex = (i * width + j) * bytesPerPixel
            let red = Double(pixelBuffer[pixelIndex])
            let green = Double(pixelBuffer[pixelIndex + 1])
            
            let tmpR = red == 0 ? 0 : log(red)
            let tmpG = green == 0 ? 0 : log(green)
            
            eimap[i][j] = 100 * (tmpR - tmpG)
        }
    }
    
    free(rawData)
    
    let meanEimap = eimap.flatMap { $0 }.reduce(0, +) / Double(width * height)
    return meanEimap
}

struct testResultContent: View {
    var testFile: TestFile
    @State var images: [UIImage] = []
    @State var customSquarePressed = false
    @State var rectToCrop: CGRect? = nil
    @State var changeView = false
    @State private var selectedTabIndex = 0
    let hhandler = HandLandmarkHandler()
    var body: some View {
        Color.white
            .ignoresSafeArea()
            .overlay(
                ZStack{
                    VStack(spacing:20){
                        //                    WebImage(url: URL(string: testFile.imageUrl ?? ""))
                        //                        .resizable()
                        //                        .scaledToFit()
                        //                        .clipShape(RoundedRectangle(cornerRadius: 20.0))
                        //                        .shadow(color: Color.black.opacity(0.4), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                        //                        .frame(width: UIScreen.main.bounds.height / 3, height: UIScreen.main.bounds.height / 3)
                        if images.count>1{
                            TabView (selection: $selectedTabIndex) {
                                ForEach(images.indices, id: \.self) { index in
                                    ZStack {
                                        
                                        Image(uiImage: images[index])
                                            .resizable()
                                            .frame(width: UIScreen.main.bounds.height / 3 * 0.75, height: UIScreen.main.bounds.height / 3)
                                        
                                    }
                                }
                            }
                            .tabViewStyle(.page)
                            .indexViewStyle(.page(backgroundDisplayMode: .interactive))
                            .frame(width: UIScreen.main.bounds.height / 3 * 0.75, height: UIScreen.main.bounds.height / 3)
                            .clipShape(RoundedRectangle(cornerRadius: 20.0))
                            .shadow(color: Color.black.opacity(0.4), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                            .onTapGesture {
                                if images.count == 4{
                                    images.popLast()
                                }
                                self.customSquarePressed = true
                                print(self.customSquarePressed)
                                
                            }
                            .onChange(of: selectedTabIndex) { newIndex in
                                changeView = newIndex == 3
                            }
                            
                        }
                        
                        
                        //                    Image(uiImage: testFile!.image!.resize(targetSize: CGSize(width: UIScreen.main.bounds.size.height/3*0.75, height: UIScreen.main.bounds.size.height/3)))
                        //                        .scaledToFit()
                        
                        
                        VStack(alignment: .leading, spacing: 10) {
                            if changeView{
                                let cropped = cropImageToRect(image: images[0], rect: rectToCrop!)!
                                let result = processImage(cropped)!
                                Divider().opacity(6)
                                Text("Erythmia Index: \(String(format: "%.2f", result))")
                                Divider().opacity(6)
                            
                            }
                            else{
                                if images.count > 0 {
                                    let palm = try? hhandler.get_palm(image: images[0].cgImage!)
                                    let result = processImage(palm!)!
                                    Text("Erythmia Index: \(String(format: "%.2f", result))")
                                    Divider().opacity(6)
                                    Text("Anemia: \((result < 13) ? "Yes" : "No")")
                                    Divider().opacity(6)
                                }

                                
                                Text("Patient ID: \(testFile.patientid)")
                                Divider().opacity(6)
                                Text("Date: \(testFile.date)")
                            }
                        }
                        .padding()
                        .foregroundStyle(.black)
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)
                        
                    }
                    if customSquarePressed{
                        pickAreaView(image: images[0], rectToCrop: $rectToCrop, customSquarePressed: $customSquarePressed, images: $images)
                    }
                }
            )
            .onAppear{
                load(url: URL(string: testFile.imageUrl ?? ""))
                //var hand_im = WebImage(url: URL(string: testFile.imageUrl ?? ""))
                
            }
        
        
        
    }
    func cropImageToRect(image: UIImage, rect: CGRect) -> UIImage? {
        guard let cgImage = image.cgImage?.cropping(to: rect) else { return nil }
        return UIImage(cgImage: cgImage)
    }

    func load(url: URL?) {
        DispatchQueue.global().async { [self] in
            if let data = try? Data(contentsOf: url!) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        images.append(image)
                        if !images.isEmpty{
                            images.append(try! hhandler.drawOnImage(image: images[0].cgImage!)!)
                            images.append((try? hhandler.get_palm(image: image.cgImage!))!)
                        }
                    }
                }
            }
        }
    }
}


//#Preview {
//    testResultContent(testFile: TestFile(iamge: id: "12345678", patientid: "123", anemia: false, date: "2403"))
//}
