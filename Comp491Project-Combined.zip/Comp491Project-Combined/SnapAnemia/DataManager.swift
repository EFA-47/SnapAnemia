//
//  DataManager.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 25.03.2024.
//
import SwiftUI
import Firebase

class DataManager: ObservableObject {
    @Published var patients: [Patient] = []
    let auth = Auth.auth()

    init() {
        fetchPatients()
    }
    func refresh(){
        fetchPatients()
    }
    func fetchPatients() {
        guard let doctorEmail = auth.currentUser?.email else {
            print("No logged-in user")
            return
        }

        let db = Firestore.firestore()
        let doctorRef = db.collection(doctorEmail)

        doctorRef.getDocuments(source: .server) { snapshot, error in
            if let error = error {
                print("Error fetching patients: \(error.localizedDescription)")
                return
            }

            if let snapshot = snapshot {
                self.patients = snapshot.documents.compactMap { document in
                    let data = document.data()

                    let id = data["id"] as? String ?? ""
                    let name = data["name"] as? String ?? ""

                    return Patient(id: id, name: name)
                }
            }
        }
    }

    func addPatients(patient: Patient, completion: @escaping (Error?) -> Void) {
        guard let doctorEmail = auth.currentUser?.email else {
            print("No logged-in user")
            return
        }

        let db = Firestore.firestore()
        let doctorRef = db.collection(doctorEmail).document(patient.id)

        doctorRef.setData(["id": patient.id, "name": patient.name]) { error in
            if let error = error {
                print("Error adding patient: \(error.localizedDescription)")
                completion(error)
            } else {
                print("Patient added successfully")
                completion(nil)
            }
        }
    }
}

    func removePatient(patientID: String) {
        let db = Firestore.firestore()
        let ref = db.collection("Patients").document(patientID)

        ref.delete { error in
            if let error = error {
                print("Error removing patient: \(error.localizedDescription)")
            } else {
                print("Patient removed successfully!")
            }
        }
    }
