//
//  ContentView.swift
//  Deneme
//
//  Created by Pınar on 7.03.2024.
//


import SwiftUI


struct CameraView: View {
    var patient_id: String
    @Binding var selectedTestFile: TestFile?
    @Binding var isCameraViewPresented: Bool
    @StateObject private var pmodel = PhotoDataModel()
    @Environment(\.testListPresentation) var testListPresentation: Binding<Bool>
    private static let barHeightFactor = 0.15
    

    var body: some View {
        ZStack{
            
//            NavigationLink(destination:WaitingTestView(input_img: pmodel.out_p_data,patient_id: patient_id, selectedTestFile:$selectedTestFile, pmodel_isPhototaken: $pmodel.isPhototaken, isCameraViewPresented: $isCameraViewPresented),
//                           isActive: $pmodel.isPhototaken){
//                EmptyView()
//            }
            GeometryReader { geometry in
                ViewfinderView(image:  $pmodel.viewfinderImage )
                    .overlay(alignment: .top) {
                        Color.black
                            .opacity(0)
                            .frame(height: geometry.size.height * Self.barHeightFactor)
                    }
                    .overlay(alignment: .bottom) {
                        buttonsView()
                            .frame(height: geometry.size.height * Self.barHeightFactor)
                            .background(.black.opacity(0))
                    }
                    .overlay(alignment: .center)  {
                        Color.clear
                            .frame(height: geometry.size.height * (1 - (Self.barHeightFactor * 2)))
                            .accessibilityElement()
                            .accessibilityLabel("View Finder")
                            .accessibilityAddTraits([.isImage])
                    }
                    .background(.black)
                    .onDisappear{pmodel.camera.stop()}
            }
            
            .task {
                await pmodel.camera.start()
                
            }
            .navigationDestination(isPresented: $pmodel.isPhototaken){
                WaitingTestView(input_img: pmodel.out_p_data,patient_id: patient_id, selectedTestFile:$selectedTestFile, pmodel_isPhototaken: $pmodel.isPhototaken, isCameraViewPresented: $isCameraViewPresented)
            }
            .navigationTitle("Camera")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarHidden(true)
            .ignoresSafeArea()
            .statusBar(hidden: true)
            
        }
        
    }
    
    private func buttonsView() -> some View {
        HStack(spacing: 60) {
            
            Spacer()
            
            Button {
                pmodel.camera.takePhoto()
                Thread.sleep(forTimeInterval: 0.5)
                print(pmodel.isPhototaken)
            } label: {
                Label {
                    Text("Take Photo")
                } icon: {
                    ZStack {
                        Circle()
                            .strokeBorder(.white, lineWidth: 3)
                            .frame(width: 62, height: 62)
                        Circle()
                            .fill(.white)
                            .frame(width: 50, height: 50)
                    }
                }
            }
            
            
            
            Spacer()
            
        }
        .buttonStyle(.plain)
        .labelStyle(.iconOnly)
        .padding()
    }
    
}
