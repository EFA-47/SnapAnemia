//
//  TestFileManager.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 29.03.2024.
//

import SwiftUI
import Firebase
import FirebaseStorage

class TestFileManager {
    static func fetchTestFiles(forPatientWithID patientID: String, completion: @escaping ([TestFile]) -> Void) {
        let db = Firestore.firestore()
        let ref = db.collection(patientID)

        ref.getDocuments(source: .server) { snapshot, error in
            if let error = error {
                print("Error fetching test files for patient \(patientID): \(error.localizedDescription)")
                completion([])
                return
            }

            if let snapshot = snapshot {
                let testFiles = snapshot.documents.compactMap { document in
                    let data = document.data()

                    let id = document.documentID
                    let patientid = data["patientid"] as? String ?? ""
                    let anemia = data["anemia"] as? Bool ?? false
                    let date = data["date"] as? String ?? ""
                    let imageUrl = data["imageUrl"] as? String ?? ""


                    return TestFile(id: id, patientid: patientid, anemia: anemia, date: date, imageUrl: imageUrl)
                }
                completion(testFiles)
            }
        }
    }


    static func addTestFile(testFile: TestFile, image: UIImage, completion: @escaping (Error?) -> Void) {
        let db = Firestore.firestore()
        let ref = db.collection(testFile.patientid).document(testFile.id)

        // Upload image to Firebase Storage
        let storageRef = Storage.storage().reference().child("\(testFile.id).jpg")
        if let imageData = image.jpegData(compressionQuality: 0.5) {
            storageRef.putData(imageData, metadata: nil) { (_, error) in
                if let error = error {
                    completion(error)
                    return
                }

                // Get the download URL of the uploaded image
                storageRef.downloadURL { (url, error) in
                    guard let imageUrl = url?.absoluteString else {
                        completion(error)
                        return
                    }

                    // Add image URL along with other data to Firestore
                    ref.setData([
                        "patientid": testFile.patientid,
                        "anemia": testFile.anemia,
                        "date": testFile.date,
                        "id": testFile.id,
                        "imageUrl": imageUrl
                        
                    ]) { error in
                        if let error = error {
                            print("Error adding test file for patient \(testFile.patientid): \(error.localizedDescription)")
                        } else {
                            print("Test file added successfully for patient \(testFile.patientid)")
                            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                                
                            }
                            
                        }
                        completion(error)
                    }
                }
            }
        }
    }

    static func getCurrentDate() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd-HH:mm"
        return dateFormatter.string(from: Date())
    }
}
