//
//  InstructionsView.swift
//  SnapAnemia
//
//  Created by Pınar on 7.05.2024.
//

import SwiftUI

struct InstructionsView: View{
    var patient_id: String
   
    @Binding var selectedTestFile: TestFile?
    @Binding var isCameraViewPresented: Bool
    
    @Environment(\.testListPresentation) var testListPresentation: Binding<Bool>
    var body: some View{
        
        Color.white
            .ignoresSafeArea()
            .overlay(
                VStack(spacing: 50){
                    
                    Image(uiImage: UIImage(resource: .parallelCamera).resize(targetSize: CGSize(width: UIScreen.main.bounds.size.height/4*0.70686, height: UIScreen.main.bounds.size.height/4)))
                    
                    Text("Please align your hand with the camera so they are parallel.")
                        .foregroundStyle(.red)
                        .font(.system(size: 20))
                        .multilineTextAlignment(.center)
                        .frame(width: 250)
                    Spacer()
                    NavigationLink(destination: CameraView(patient_id: patient_id, selectedTestFile: $selectedTestFile, isCameraViewPresented: $isCameraViewPresented)){
                            Text("Continue")
                                .foregroundColor(.white)
                                .frame(width: 200, height: 60)
                                .background(Color.blue)
                                .cornerRadius(27)
                                .padding()
                        
                        .frame(maxHeight: 60, alignment: .bottom)
                    }
                }
            )
            .navigationBarHidden(true)
    }
}

extension UIImage {

    func resize(targetSize: CGSize) -> UIImage {
        return UIGraphicsImageRenderer(size:targetSize).image { _ in
            self.draw(in: CGRect(origin: .zero, size: targetSize))
        }
    }

}



//#Preview {
//    InstructionsView(patient_id: "123")
//}
