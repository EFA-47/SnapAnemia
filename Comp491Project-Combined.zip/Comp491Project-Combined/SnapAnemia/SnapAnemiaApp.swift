//
//  SnapAnemiaApp.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 8.03.2024.
//

import SwiftUI
import Firebase
@main
struct SnapAnemiaApp: App {

    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            PatientOrDoctor()
        }
    }
}
