//
//  ContentView.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 8.03.2024.
//


import SwiftUI
import Firebase

struct ContentView: View {
    
    @State private var tckn = ""
    @State private var password = ""
    @State private var UserIsLoggedIn = false
    
    //    var body: some View {
    //        if UserIsLoggedIn{
    //            testListView(patientid: email)
    //        }else{
    //            content
    //        }
    //    }
    
    var body: some View {
        if UserIsLoggedIn{
            testListView(patientid: tckn)
        }
        else{
            contextPatient
        }
    }
    var contextPatient: some View{
        
            ZStack {
                Color.black
                
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .foregroundStyle(.linearGradient(colors: [.red,.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 1000, height: 1000)
                    .rotationEffect(.degrees(45))
                
                VStack(spacing: 20){
                    Text("Patient")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .offset(x: 0, y: -100)
                    
                    SecureField("TCKN", text: $tckn)
                        .foregroundColor(.white)
                        .textFieldStyle(.plain)
                        .placeholder(when: tckn.isEmpty){
                            Text("")
                                .foregroundColor(.white)
                                .bold()
                                .textFieldStyle(.plain)
                        }
                    Rectangle()
                        .frame(width:350, height: 1)
                        .foregroundColor(.white)
                    
                    //                SecureField("Password", text: $password)
                    //                    .foregroundColor(.white)
                    //                    .textFieldStyle(.plain)
                    //                    .placeholder(when: password.isEmpty){
                    //                        Text("")
                    //                            .foregroundColor(.white)
                    //                            .bold()
                    //                            .textFieldStyle(.plain)
                    //                    }
                    //                Rectangle()
                    //                    .frame(width:350, height: 1)
                    //                    .foregroundColor(.white)
                    
                    Button{
                        login()
                    } label: {
                        Text("Login")
                            .bold()
                            .frame(width: 200, height: 40)
                            .background(RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(.linearGradient(colors: [.cyan, .cyan], startPoint: .top, endPoint: .bottomTrailing)))
                            .foregroundColor(.blue)
                    }
                    .padding(.top)
                    .offset(y:120)
                    
                    //                Button{
                    //                  login()
                    //                }label: {
                    //                Text("Already have an account? Login")
                    //                        .bold()
                    //                        .foregroundColor(.blue)
                    //                }
                    //                .padding(.top)
                    //                .offset(y:120)
                    
                }
                
                .frame(width: 350)
                //            .onAppear{
                //                Auth.auth().addStateDidChangeListener { auth, user in
                //                    if user != nil {
                //                        UserIsLoggedIn.toggle()
                //                    }
                //                }
                //            }
            }
        }
        //            .navigationDestination(isPresented: $UserIsLoggedIn){
        //                testListView(patientid: tckn)
    
    
    //        .ignoresSafeArea()
    
    //    func register(){
    //        Auth.auth().createUser(withEmail: email, password: password) {
    //            result, error in
    //            if error != nil {
    //                print(error!.localizedDescription  )
    //            }
    //        }
    //    }
    func login(){
        UserIsLoggedIn.toggle()
    }

}

#Preview {
    ContentView()
}

extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {

        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}


