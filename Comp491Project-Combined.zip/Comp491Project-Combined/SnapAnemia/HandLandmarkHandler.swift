//
//  HandLandmarkHandler.swift
//  Deneme
//
//  Created by Pınar on 23.04.2024.
//

import Foundation
import SwiftUI
import MediaPipeTasksVision
import AVKit
import MediaPipeTasksVision
import UIKit

struct cust_point{
    let x: CGFloat
    let y: CGFloat
}

enum PalmDetectionError: Error {
    case insufficientLandmarks
}

final class HandLandmarkHandler: ObservableObject{
    var palm: Image?
    var nail: Image?
    var hand_skel: Image?
    var hLandmarker: HandLandmarker?
    
    init(){
        
        let modelPath = Bundle.main.path(forResource: "hand_landmarker", ofType: "task")
        let options = HandLandmarkerOptions()
        options.baseOptions.modelAssetPath = modelPath!
        options.runningMode = .image
        options.minHandDetectionConfidence = 0.8
        options.minHandPresenceConfidence = 0.8
        options.minTrackingConfidence = 0.8
        options.numHands = 1
        
        do {
            self.hLandmarker = try HandLandmarker(options: options)
            
        }
        catch{
            print("Error initializing HandLandmarker: \(error)")
            
        }
    }
    
    
    private func saveImage(image: UIImage) -> Bool {
        guard let data = image.jpegData(compressionQuality: 1) ?? image.pngData() else {
            return false
        }
        guard let directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) as NSURL else {
            return false
        }
        do {
            
            try data.write(to: directory.appendingPathComponent("fileName.png")!)
            return true
        } catch {
            print(error.localizedDescription)
            return false
        }
    }
    
    func drawOnImage(image: CGImage) throws -> UIImage? {
        
        let image = UIImage(cgImage: image)
        do{
            guard let hLandmarker = self.hLandmarker else {
                // Handle the case when hLandmarker is nil
                return nil
            }
            
            let mp_image = try MPImage(uiImage: image)
            
            let result = try hLandmarker.detect(image: mp_image)
            
            guard result.landmarks.count > 0 && result.landmarks[0].count == 21 else {
                // Handle the scenario when the landmarks array is empty or doesn't contain enough elements
                throw PalmDetectionError.insufficientLandmarks
            }
            
            guard result.landmarks[0][0].y < 1 && result.landmarks[0][0].y > 0  else {
                // Handle the scenario when the landmarks array is empty or doesn't contain enough elements
                throw PalmDetectionError.insufficientLandmarks
            }

            
            UIGraphicsBeginImageContext(image.size)
            image.draw(at: CGPoint.zero)
            
            let context = UIGraphicsGetCurrentContext()!
            
            for landmark in result.landmarks[0]{
                let x = CGFloat(landmark.x) * image.size.width
                let y = CGFloat(landmark.y) * image.size.height
                
                context.setStrokeColor(UIColor.red.cgColor)
                context.setAlpha(1)
                context.setLineWidth(25.0)
                context.addEllipse(in: CGRect(x: x-20, y: y-20, width: 40, height: 40))
                context.drawPath(using: .stroke)
            }
            
            let start_f = [4, 8, 12, 16, 20]
            for f in start_f{
                for i in stride(from: 0, to: 3, by: 1){
                    let x1 = CGFloat(result.landmarks[0][f-i].x) * image.size.width
                    let y1 = CGFloat(result.landmarks[0][f-i].y) * image.size.height
                    
                    let x2 = CGFloat(result.landmarks[0][f-i-1].x) * image.size.width
                    let y2 = CGFloat(result.landmarks[0][f-i-1].y) * image.size.height
                    
                    context.setLineWidth(10.0)
                    context.setStrokeColor(UIColor.green.cgColor)
                    context.move(to: CGPoint(x: x1, y: y1))
                    context.addLine(to: CGPoint(x: x2, y: y2))
                    context.drawPath(using: .stroke)
                }
                
            }
            let palm = [0, 5, 9, 13, 17, 0, 1]
            for p in 0..<(palm.count - 1){
                let x1 = CGFloat(result.landmarks[0][palm[p]].x) * image.size.width
                let y1 = CGFloat(result.landmarks[0][palm[p]].y) * image.size.height
                
                let x2 = CGFloat(result.landmarks[0][palm[p+1]].x) * image.size.width
                let y2 = CGFloat(result.landmarks[0][palm[p+1]].y) * image.size.height
                
                context.setLineWidth(10.0)
                context.setStrokeColor(UIColor.green.cgColor)
                context.move(to: CGPoint(x: x1, y: y1))
                context.addLine(to: CGPoint(x: x2, y: y2))
                context.drawPath(using: .stroke)
            }
            
            
            
            let myImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            
            return myImage!
        }
        catch{
            throw PalmDetectionError.insufficientLandmarks
        }
        return nil
    }

    func get_palm(image: CGImage) throws ->UIImage?{
        
        let image = UIImage(cgImage: image)
        do{
            guard let hLandmarker = self.hLandmarker else {
                // Handle the case when hLandmarker is nil
                return nil
            }
            
            let mp_image = try MPImage(uiImage: image)
            let result = try hLandmarker.detect(image: mp_image)
            
                        
            guard result.landmarks.count > 0 && result.landmarks[0].count == 21 else {
                // Handle the scenario when the landmarks array is empty or doesn't contain enough elements
                throw PalmDetectionError.insufficientLandmarks
            }
            
            guard result.landmarks[0][0].y < 1 && result.landmarks[0][0].y > 0  else {
                // Handle the scenario when the landmarks array is empty or doesn't contain enough elements
                throw PalmDetectionError.insufficientLandmarks
            }

            
            let knukcle_out_right = cust_point(x: CGFloat(result.landmarks[0][5].x) * image.size.width,
                                               y: CGFloat(result.landmarks[0][5].y) * image.size.height)
            
            let knuckle_in_right = cust_point(x: CGFloat(result.landmarks[0][9].x) * image.size.width,
                                              y: CGFloat(result.landmarks[0][9].y) * image.size.height)
            
            let knuckle_out_left = cust_point(x: CGFloat(result.landmarks[0][17].x) * image.size.width,
                                              y: CGFloat(result.landmarks[0][17].y) * image.size.height)
            let knuckle_in_left = cust_point(x: CGFloat(result.landmarks[0][13].x) * image.size.width,
                                             y: CGFloat(result.landmarks[0][13].y) * image.size.height)
            
            let wrist = cust_point(x: CGFloat(result.landmarks[0][0].x) * image.size.width,
                                   y: CGFloat(result.landmarks[0][0].y) * image.size.height)
            
            let cropWidth = abs((knukcle_out_right.x * 0.6+knuckle_in_right.x * 0.4) - (knuckle_out_left.x * 0.6+knuckle_in_left.x * 0.4))
            
            let y_smallest = min(knuckle_in_left.y, knuckle_in_right.y, knuckle_out_left.y, knukcle_out_right.y)
            
            let cropHeight = CGFloat(0.7*(wrist.y - y_smallest))
            
            
            let x_center = CGFloat((knuckle_in_left.x+knuckle_in_right.x+knuckle_out_left.x+knukcle_out_right.x)/4)
            let y_center = CGFloat((knuckle_in_left.y+knuckle_in_right.y+knuckle_out_left.y+knukcle_out_right.y)/4 * 0.45 + wrist.y * 0.55)
            
            let x_orig = x_center - cropWidth/2
            let y_orig = y_center - 1.2 * cropHeight/2

            do {
                guard let croppedImage = self.cropImage(image, x_center: x_orig, y_center: y_orig, cropWidth: cropWidth, cropHeight: cropHeight) else {
                    throw PalmDetectionError.insufficientLandmarks
                }
                return croppedImage
            } catch {
                throw PalmDetectionError.insufficientLandmarks
            }
        }
        catch{
            throw PalmDetectionError.insufficientLandmarks
        }
        return nil
    }
   
    func get_nails(image: CGImage) throws ->UIImage?{
        let image = UIImage(cgImage: image)
        do{
            guard let hLandmarker = self.hLandmarker else {
                // Handle the case when hLandmarker is nil
                return nil
            }
            
           
            
            let mp_image = try MPImage(uiImage: image)
            let result = try hLandmarker.detect(image: mp_image)
            
            guard result.landmarks.count > 0 && result.landmarks[0].count == 21 else{
                // Handle the scenario when the landmarks array is empty or doesn't contain enough elements
                throw PalmDetectionError.insufficientLandmarks
            }
 
            print( result.landmarks[0][0].x, result.landmarks[0][0].x)
            let index_finger_nail = cust_point(x: CGFloat(result.landmarks[0][8].x) * image.size.width,
                                               y: CGFloat(result.landmarks[0][8].y) * image.size.height)
            
            let index_f_joint = cust_point(x: CGFloat(result.landmarks[0][7].x) * image.size.width,
                                           y: CGFloat(result.landmarks[0][7].y) * image.size.height)
            
            let cropHeight = abs(index_finger_nail.y - index_f_joint.y) * 0.6
            let cropWidth = cropHeight * 0.6
            let x_orig = index_finger_nail.x - cropWidth/2
            let y_orig = index_finger_nail.y - cropHeight/2
            
            do {
                guard let croppedImage = self.cropImage(image, x_center: x_orig, y_center: y_orig, cropWidth: cropWidth, cropHeight: cropHeight) else {
                    throw PalmDetectionError.insufficientLandmarks
                }
                return croppedImage.rotate(radians: .pi/2)
            } catch {
                throw PalmDetectionError.insufficientLandmarks
            }
            
        }
        catch{
          
            throw PalmDetectionError.insufficientLandmarks
           
        }
        return nil
    }
    
    private func cropImage(_ inputImage: UIImage, x_center: CGFloat, y_center: CGFloat, cropWidth: CGFloat, cropHeight: CGFloat) -> UIImage?
    {
        
        
        // Scale cropRect to handle images larger than shown-on-screen size
        let cropZone = CGRect(x:x_center,
                              y:y_center,
                              width:cropWidth,
                              height:cropHeight)


        // Perform cropping in Core Graphics
        guard let cutImageRef: CGImage = inputImage.cgImage?.cropping(to:cropZone)
        else {
            return nil
        }


        // Return image to UIImage
        let croppedImage: UIImage = UIImage(cgImage: cutImageRef)
        let resized_im = resizeImage(image: croppedImage, targetSize: CGSize(width: Double(200), height: Double(200 * cropHeight/cropWidth)))
        
//        print(resized_im?.size.width, resized_im?.size.height)
        return resized_im
    }

    private func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage? {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(origin: .zero, size: newSize)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
//        print(newImage?.size.width, newImage?.size.height)
        return newImage
    }
    
    
}

extension UIImage {
    func rotate(radians: Float) -> UIImage? {
            var newSize = CGRect(origin: CGPoint.zero, size: self.size).applying(CGAffineTransform(rotationAngle: CGFloat(radians))).size
            // Trim off the extremely small float value to prevent core graphics from rounding it up
            newSize.width = floor(newSize.width)
            newSize.height = floor(newSize.height)
            
            UIGraphicsBeginImageContextWithOptions(newSize, false, self.scale)
            guard let context = UIGraphicsGetCurrentContext() else { return nil }
            
            // Move origin to middle
            context.translateBy(x: newSize.width/2, y: newSize.height/2)
            // Rotate around middle
            context.rotate(by: CGFloat(radians))
            // Draw the image at its center
            self.draw(in: CGRect(x: -self.size.width/2, y: -self.size.height/2, width: self.size.width, height: self.size.height))
        
            let newImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return newImage
        }
}

