//
//  PhotoOrArchive.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 25.03.2024.
//

import SwiftUI

struct PhotoOrArchive: View {
    var id: String
    @StateObject var dataManager = DataManager()
    var body: some View {
        NavigationLink(destination: testListView(patientid: "123")
            .environmentObject(dataManager)){
                Text( "go archive")
            }
        Button{
//            take photo
        } label: {
            Image(systemName: "camera.circle")
                .imageScale(.large)
        }
            .padding(.top)
            .offset(y:120)
    }
}

#Preview {
    PhotoOrArchive(id: "123")
}
