//
//  NewPatientSheet.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 29.04.2024.
//

import SwiftUI

struct NewPatientSheet: View {

    @EnvironmentObject var dataManager: DataManager
    @Binding var sheetToggle: Bool
    @State private var newPatientname = ""
    @State private var newPatientid = ""

    var body: some View {
        VStack {
            TextField("Patient name", text: $newPatientname)
            TextField("Patient TCKN", text: $newPatientid)
            Button{
                dataManager.addPatients(patient:  Patient(id: newPatientid, name: newPatientname)){
                    error in
                    if let error=error{
                        print("Error Occured----------\n")
                        print(error.localizedDescription)
                    }
                    else{
                        dataManager.refresh()
                        sheetToggle = false
                    }
                }
                
                
                
            } label:{
                Text("Save")
            }
        }
    }
}

//#Preview {
//    NewPatientSheet()
//}
