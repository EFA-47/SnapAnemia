//
//  CustomEnvironmentProperties.swift
//  SnapAnemia
//
//  Created by Pınar on 13.05.2024.
//

import Foundation
import SwiftUI

struct testListPresentationKey: EnvironmentKey{
    static let defaultValue: Binding<Bool> = .constant(false)
}

extension EnvironmentValues{
    var testListPresentation: Binding<Bool>{
        get{
            self[testListPresentationKey.self]
        }
        set{
            self[testListPresentationKey.self] = newValue
        }
    }
}
