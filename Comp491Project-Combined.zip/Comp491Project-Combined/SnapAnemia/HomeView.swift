//
//  HomeView.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 8.03.2024.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var dataManager: DataManager
    @State private var selectedPatientID: String = ""
    @State private var sheetToggle: Bool = false
    var body: some View {
        Color.white
            .ignoresSafeArea()
            .overlay(
                VStack {
                    List(dataManager.patients, id: \.id) { patient in
                        NavigationLink{testListView(patientid: patient.id)} label: {
                                        VStack(alignment: .leading) {
                                            Text("\(patient.name)")
                                        }


                        }
                    }
                    .navigationTitle("Patients")
                    .navigationBarItems(trailing: Button(action: {
                        sheetToggle.toggle()
                       
                    } ,label: {
                        Image(systemName: "plus")
                    }))
                    .sheet(isPresented: $sheetToggle) {
                        NewPatientSheet(sheetToggle: $sheetToggle)
                    
                    }
                }
                .navigationViewStyle(.stack)
            )
    }
}

#Preview {
    HomeView()
        .environmentObject(DataManager())
        .preferredColorScheme(.dark)
}

