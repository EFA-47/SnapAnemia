//
//  PatientOrDoctor.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 10.03.2024.
//

import SwiftUI
import UIKit

struct PatientOrDoctor: View {
    var body: some View {
        NavigationView {
            ZStack{
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .foregroundStyle(.linearGradient(colors: [.white,.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 1000, height: 1000)
                    .rotationEffect(.degrees(45))

                VStack{

                    LinkCardDoctor(number: "Doctor")

                    LinkCardpatient(number: "Patient")
                }
            }
        }
    }
}

struct LinkCardDoctor: View {
    let number: String
    @State private var isActive = false
    @State private var isBig = false
    let card_length = UIScreen.main.bounds.height / 3.5
    var body: some View {
        Text("Doctor")
            .font(.system(size: 40, weight: .bold, design: .rounded))
        Image("DoctorImage")
          .resizable()
          .aspectRatio(contentMode: .fill)
          .frame(width: card_length, height: card_length)
          .clipShape(RoundedRectangle(cornerRadius: 20))
          .overlay {
            RoundedRectangle(cornerRadius: 20)
              .stroke(.white, lineWidth: 3)
          }
            .background(
                NavigationLink(
                destination: DoctorLogin(),
                isActive: $isActive) {
                EmptyView()
            })

            .onTapGesture {
                isActive.toggle()    // << activate link !!
            }
            .onLongPressGesture {
                isBig.toggle()       // << alterante action !!
            }
    }
}
struct LinkCardpatient: View {
    let number: String
    @State private var isActive = false
    @State private var isBig = false
    let card_length = UIScreen.main.bounds.height / 3.5
    var body: some View {
        Text("Patient")
            .font(.system(size: 40, weight: .bold, design: .rounded))
        Image("PatientImage")
          .resizable()
          .aspectRatio(contentMode: .fill)
          .frame(width: card_length, height: card_length)
          .clipShape(RoundedRectangle(cornerRadius: 20))
          .overlay {
            RoundedRectangle(cornerRadius: 20)
              .stroke(.white, lineWidth: 3)
          }
            .background(NavigationLink(
                destination: ContentView(),
                isActive: $isActive) {
                EmptyView()
            })
            .onTapGesture {
                isActive.toggle()    // << activate link !!
            }
            .onLongPressGesture {
                isBig.toggle()       // << alterante action !!
            }
    }
}

#Preview {
    PatientOrDoctor()
        .preferredColorScheme(.dark)
}

