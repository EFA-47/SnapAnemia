//
//  testListView.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 25.03.2024.
//

import SwiftUI
import Photos
import Firebase
import FirebaseStorage

struct testListView: View {
    let patientid: String
    @State private var new_test = false
    var new_test_id: String?
    @State private var testFiles: [TestFile] = []
    @State private var selectedTestFile: TestFile?
    @State private var isCameraViewPresented = false
    @State private var testListPresenting: Bool = false
    
    var body: some View {
        NavigationStack{
//            NavigationLink(destination: InstructionsView(patient_id: patientid, selectedTestFile:$selectedTestFile,isCameraViewPresented: $isCameraViewPresented), 
//                           isActive: $isCameraViewPresented) {
//                                        EmptyView()
//                                        }
            List(testFiles, id: \.id) { testFile in
                Button(action: {
                    self.selectedTestFile = testFile
                }) {
                    Text("\(testFile.date)")
                }
            }
            .sheet(item: $selectedTestFile) { testFile in
                testResultContent(testFile: testFile)
                    .overlay(
                            // Draggable handle
                            RoundedRectangle(cornerRadius: 5)
                                .frame(width: 80, height: 5)
                                .foregroundColor(.gray)
                                .padding(.top, 10), // Adjust top padding as needed
                            alignment: .top
                        )
            }
            .navigationTitle("Tests")
            .navigationBarItems(trailing: Button(action: {
                testListPresenting = true
                self.isCameraViewPresented = true
                //            sheetToggle.toggle()
                //            var testFile = TestFile(id: "123456789098765", patientid: "000", anemia: true, date: "currDate")
                //            TestFileManager.addTestFile(testFile: testFile)
            } ,label: {
                Image(systemName: "camera")
            }))
            
            .onAppear {
                
                fetchTestFiles()
                if new_test{
                    selectedTestFile = self.testFiles.first(where: { $0.id == new_test_id! })
                }
            }
            .navigationDestination(isPresented: $isCameraViewPresented) {
                            InstructionsView(patient_id: patientid, selectedTestFile: $selectedTestFile, isCameraViewPresented: $isCameraViewPresented)
                        }
                        .environment(\.testListPresentation, $testListPresenting)
            //        .sheet(isPresented: $sheetToggle) {
            //            NewTestSheet()
        }
        
    }

    private func fetchTestFiles() {
        TestFileManager.fetchTestFiles(forPatientWithID: patientid) { files in
            self.testFiles = files
        }
    }
}


#Preview {
    testListView(patientid: "123")
}
