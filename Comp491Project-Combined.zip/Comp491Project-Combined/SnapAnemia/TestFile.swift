//
//  TestFile.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 29.03.2024.
//

import SwiftUI

struct TestFile: Identifiable {
    var id:         String
    var patientid:  String
    var anemia:     Bool
    var date:       String
    var imageUrl:   String?
}
