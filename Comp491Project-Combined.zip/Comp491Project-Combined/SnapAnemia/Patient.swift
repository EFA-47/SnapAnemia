//
//  Patient.swift
//  SnapAnemia
//
//  Created by Emir Fatih AYYILDIZ on 25.03.2024.
//

import SwiftUI

struct Patient: Identifiable {
    var id:     String
    var name:   String
}
