//
//  SheetManager.swift
//  SnapAnemia
//
//  Created by Pınar on 11.05.2024.
//

import SwiftUI

class SheetManager: ObservableObject {
    @Published var isSheetPresented = false
    @Published var isSecondSheetPresented = false
    @Published var isThirdSheetPresented = false
}
